
import './App.css';
import StateHook1 from './StateHook1';
import StateHook2 from './StateHook2';


function App() {
  return (
    <div className="App">
        <StateHook2></StateHook2>
    </div>



  );
}

export default App;
