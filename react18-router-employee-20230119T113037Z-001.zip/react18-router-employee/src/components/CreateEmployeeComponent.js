
import React, { Component } from 'react'
class CreateEmployeeComponent extends Component {
    

    render() {
        return (
            <div>
                <h1>CreateEmployeeComponent</h1>
                <h2>CreateEmployeeComponent...</h2>
            </div>
        )
    }
}

export default CreateEmployeeComponent