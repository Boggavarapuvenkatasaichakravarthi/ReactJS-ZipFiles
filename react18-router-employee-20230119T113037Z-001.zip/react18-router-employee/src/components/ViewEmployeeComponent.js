
import React, { Component } from 'react'
class ViewEmployeeComponent extends Component {
   

    render() {
        return (
            <div>
                <h1>ViewEmployeeComponent</h1>
                <h2>ViewEmployeeComponent ...</h2>
            </div>
        )
    }
}

export default ViewEmployeeComponent