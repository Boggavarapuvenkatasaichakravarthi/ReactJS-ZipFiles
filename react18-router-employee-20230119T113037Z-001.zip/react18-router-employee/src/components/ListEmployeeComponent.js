
import React, { Component } from 'react'
class ListEmployeeComponent extends Component {
    

    render() {
        return (
            <div>
                <h1>ListEmployeeComponent</h1>
                <h2>List All Employes...</h2>
            </div>
        )
    }
}

export default ListEmployeeComponent