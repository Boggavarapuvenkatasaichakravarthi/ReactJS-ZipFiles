function FooterComponent() {
  
  
    return (
      <div className="App">
       
       <h1>FooterComponent</h1>
      </div>
    );
  
  }
  
  export default FooterComponent;