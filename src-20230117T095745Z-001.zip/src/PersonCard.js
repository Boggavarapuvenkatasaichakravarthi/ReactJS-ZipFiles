 


const PersonCard = () => {
    return(
        <div className="personcss">
            <h3>Full Name :</h3>
            <p>Age :</p>
            <p>Job : </p>

        </div>
    )
}

export default PersonCard;