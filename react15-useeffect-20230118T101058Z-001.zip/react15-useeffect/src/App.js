
import './App.css';
import UseEffectHook1 from './UseEffectHook';

function App() {
  return (
    <div className="App">
      <UseEffectHook1></UseEffectHook1>
    </div>
  );
}

export default App;
