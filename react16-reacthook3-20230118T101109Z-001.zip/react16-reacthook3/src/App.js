import UseEffectHook1 from './UseEffectHook1';
import UseEffectHook from './UseEffectHook';


import './App.css';


function App() {
  return (
    <div className="App">
         <UseEffectHook1/>
    </div>
  );
}

export default App;
