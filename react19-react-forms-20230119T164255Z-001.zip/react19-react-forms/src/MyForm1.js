
function MyForm1() {
    return(
      <form>
         <label>Enter your Name :
              <input type="text"/>

         </label>
      </form>

    )
}

export default MyForm1;