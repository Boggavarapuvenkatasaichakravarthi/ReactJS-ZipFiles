import MyForm1 from './MyForm1';


import MyForm2 from './MyForm2';
import MyForm3 from './MyForm3'
import MyForm4 from './MyForm4'
import MyForm5 from './MyForm5'
import MyForm6 from './MyForm6'
function App() {
  return (
    <div className="App">
       <MyForm6></MyForm6>
    </div>
  );
}

export default App;
